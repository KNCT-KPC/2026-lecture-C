#include <stdio.h>

int main(void) {
    int num;

    while (1) {
        printf("Please select the number.\n");
        printf("  1: Increment\n");
        printf("  2: Decrement\n");
        printf("  3: Exit\n");
        printf("number? > ");
        scanf("%d", &num);

        switch (num) {
        case 1:
            increment();
            break;

        case 2:
            decrement();
            break;

        case 3:
            return 0;

        default:
            printf("Invalid number.\n");
            break;
        }

        // printf("Current counter: %d\n", counter);
    }

    return 0;
}